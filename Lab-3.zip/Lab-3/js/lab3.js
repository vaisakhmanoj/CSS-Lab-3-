document.addEventListener('DOMContentLoaded', (event) => {
    // Get all the tab links
    const tabs = document.querySelectorAll('.tabs ul li a');
    const tabPanels = document.querySelectorAll('.tabs [role="tabpanel"]');

    // Function to deactivate all tabs and tab panels
    function deactivateTabs() {
        tabs.forEach(tab => {
            tab.classList.remove('active');
        });
        tabPanels.forEach(panel => {
            panel.classList.remove('active');
        });
    }

    // Function to activate a tab and the corresponding tab panel
    function activateTab(tab) {
        const panelId = tab.href.split('#')[1];
        const panel = document.getElementById(panelId);
        tab.classList.add('active');
        panel.classList.add('active');
    }

    // Add click event to each tab
    tabs.forEach(tab => {
        tab.addEventListener('click', (e) => {
            e.preventDefault();
            deactivateTabs();
            activateTab(tab);
        });
    });
});
